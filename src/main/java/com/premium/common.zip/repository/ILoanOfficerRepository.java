package com.premium.repository;

import org.springframework.data.repository.CrudRepository;

import com.premium.model.LoanOfficer;

public interface ILoanOfficerRepository extends CrudRepository<LoanOfficer, Integer>{

}
