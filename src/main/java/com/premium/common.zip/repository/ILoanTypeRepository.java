package com.premium.repository;

import org.springframework.data.repository.CrudRepository;

import com.premium.model.LoanType;

public interface ILoanTypeRepository extends CrudRepository<LoanType, Integer>{

}
