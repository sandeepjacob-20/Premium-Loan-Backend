package com.premium.service;

import java.util.List;

import com.premium.model.Status;

public interface IStatusService {
	//list all status
	public List<Status> getAllStatus();
}
