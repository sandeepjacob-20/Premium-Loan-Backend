package com.premium.service;

import java.util.List;

import com.premium.model.LoanType;

public interface ILoanTypeService {
	public List<LoanType> getAllLoanTypes();
}
