package com.premium.service;

import java.util.List;
import com.premium.model.VerificationStatus;


public interface IVerificationStatusService {
	//list all verification status
	public List<VerificationStatus> getAllVerificationStatus();
}
