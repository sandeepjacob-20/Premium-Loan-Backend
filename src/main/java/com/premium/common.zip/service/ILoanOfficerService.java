package com.premium.service;

import java.util.List;

import com.premium.model.LoanOfficer;

public interface ILoanOfficerService {
	public List<LoanOfficer> getAllLoanOfficers();
}
